window.__require = function e(t, r, o) {
function n(a, i) {
if (!r[a]) {
if (!t[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (s) return s(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var u = r[a] = {
exports: {}
};
t[a][0].call(u.exports, function(e) {
return n(t[a][1][e] || e);
}, u, u.exports, e, t, r, o);
}
return r[a].exports;
}
for (var s = "function" == typeof __require && __require, a = 0; a < o.length; a++) n(o[a]);
return n;
}({
BundleControl: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "d36e6QqFLtP2bEo6GdVatmR", "BundleControl");
var o, n = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
o(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), s = this && this.__decorate || function(e, t, r, o) {
var n, s = arguments.length, a = s < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var i = e.length - 1; i >= 0; i--) (n = e[i]) && (a = (s < 3 ? n(a) : s > 3 ? n(t, r, a) : n(t, r)) || a);
return s > 3 && a && Object.defineProperty(t, r, a), a;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = (a.property, function(e) {
n(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
r = t;
t.init = function(e) {
this.serverVersion = e;
};
t.prototype.start = function() {
r.checkUpdate(null);
};
t.checkUpdate = function(e) {
console.log("checkUpdate");
var t = Date.now(), o = r.DOMAIN + "check.json?t=" + t;
console.log("checkUpdate " + o);
var n = new XMLHttpRequest();
n.onreadystatechange = function() {
console.log("xhr.readyState " + n.readyState + " " + n.status + " " + n.statusText);
if (4 == n.readyState && n.status >= 200 && n.status < 400) {
var t = JSON.parse(n.responseText);
console.log("response config ", JSON.stringify(t));
if (t.is_update) {
r.urlInfo = t;
r.loadDataBundle(e);
}
} else n.readyState;
};
n.ontimeout = function() {
cc.log("ON TIME OUT");
};
n.onerror = function() {
cc.log("ON ERROR");
};
n.timeout = 2e4;
n.open("GET", o, !0);
n.send();
};
t.loadDataBundle = function(e) {
console.log("loadserverVersion");
var t = Date.now(), o = "https://cdn.shibapoker.club/remote-assets/assets";
r.urlInfo.url && (o = r.urlInfo.url);
o = o + "/AssetBundleVersion.json?t=" + t;
var n = new XMLHttpRequest();
console.log("loadserverVersion " + o);
n.onreadystatechange = function() {
console.log("xhr.readyState " + n.readyState + " " + n.status + " " + n.statusText);
if (4 == n.readyState && n.status >= 200 && n.status < 400) {
var t = JSON.parse(n.responseText);
console.log("response config ", JSON.stringify(t));
r.serverVersion = t;
r.checkGame(e);
} else n.readyState;
};
n.ontimeout = function() {
console.log("ON TIME OUT");
};
n.onerror = function() {
console.log("ON ERROR");
};
n.timeout = 2e4;
n.open("GET", o, !0);
n.send();
};
t.checkGame = function(e) {
console.log("checkGame");
var t = !1, o = [], n = {
bundles: o,
version: null == r.serverVersion.version ? "0.0.0" : r.serverVersion.version,
entrypoint: "db://assets/Loading/scenes/Loading.fire"
};
o.push({
url: r.serverVersion.internal.url,
hash: r.serverVersion.internal.hash
});
o.push({
url: r.serverVersion.resources.url,
hash: r.serverVersion.resources.hash
});
o.push({
url: r.serverVersion.main.url,
hash: r.serverVersion.main.hash
});
var s = cc.sys.localStorage.getItem("UptAssetManifest");
if (s) try {
var a = JSON.parse(s);
a && a.version && r.versionCompareHandle(n.version, a.version) > 0 && (t = !0);
} catch (e) {
cc.sys.localStorage.removeItem("UptAssetManifest");
t = !0;
} else t = !0;
if (1 == t) {
cc.sys.localStorage.setItem("UptAssetManifest", JSON.stringify(n));
cc.sys.localStorage.setItem("UptEntrypoint", n.entrypoint);
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 1500);
} else e && e();
};
t.versionCompareHandle = function(e, t) {
console.log("JS Custom Version Compare: version A is " + e + ", version B is " + t);
for (var r = e.split("."), o = t.split("."), n = 0; n < r.length; ++n) {
var s = parseInt(r[n]), a = parseInt(o[n] || 0);
if (s !== a) return s - a;
}
return o.length > r.length ? -1 : 0;
};
var r;
t.serverVersion = {};
t.urlInfo = {};
t.DOMAIN = "https://n3frxbct2xywut1cmzy89hi2z.gitlab.io/i1ymjfaray9oyuqhp7lj/";
return r = s([ i ], t);
}(cc.Component));
r.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "BundleControl" ]);